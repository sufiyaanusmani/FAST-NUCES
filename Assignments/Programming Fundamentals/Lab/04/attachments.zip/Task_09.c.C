#include <stdio.h>

int main(){
	int num, d1, d2, d3, d4, d5, reverse, remaining;
	
	printf("Enter a five digit number: ");
	scanf("%d", &num);
	
	d5 = num % 10;
	remaining = num - d5;
	d4 = (remaining % 100) / 10;
	remaining = remaining - (d4*10);
	d3 = (remaining % 1000) / 100;
	remaining = remaining - (d4*100);
	return 0;
}
