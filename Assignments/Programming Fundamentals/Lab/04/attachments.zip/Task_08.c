#include <stdio.h>

int main(){
	int num1, num2;
	
	printf("Enter number 1: ");
	scanf("%d", &num1);
	printf("\nEnter number 2: ");
	scanf("%d", &num2);
	
	printf("\nNumber 1: %d", num2);
	printf("\nNumber 2: %d\n", num1);
}
